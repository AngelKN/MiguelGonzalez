package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.atributos.Libro;

public class ActualizarLibroActivity extends AppCompatActivity {

    EditText txtNombre, txtAutor, txtCantidad, txtUrl, txtImagen, txtDescripcion, error;
    ImageButton btnReturn;
    Button btnActualizar;
    Libro lib, libro;
    int id=0;
    boolean correcto;
    SharedPreference sp;
    TextView txtRol, txtNombreA;
    String validar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualizar_libro);
        btnReturn=findViewById(R.id.btnMenuAdmin);
        btnActualizar=findViewById(R.id.btnActualizarLibro);
        txtNombre=findViewById(R.id.txtNombreLibro);
        txtAutor=findViewById(R.id.txtAutorLibro);
        txtCantidad=findViewById(R.id.txtCantidadLibros);
        txtUrl=findViewById(R.id.txtUrlLibro);
        txtImagen=findViewById(R.id.txtImagenLibro);
        txtDescripcion=findViewById(R.id.txtDescripcionLibro);
        error=findViewById(R.id.txtError);
        error.setInputType(InputType.TYPE_NULL);
        correcto = false;
        lib = new Libro();


        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));

        if(savedInstanceState == null){
                Bundle extras = getIntent().getExtras();
                if(extras == null){
                    id = Integer.parseInt(null);
                }else{
                    id = extras.getInt("ID");
                }
        }else
        {
            id = (int) savedInstanceState.getSerializable("ID");
        }

        DBLibreria libreria = new DBLibreria(ActualizarLibroActivity.this);
        libro = libreria.verLibro(id);

        if(libro != null) {
            txtNombre.setText(libro.getNombreLi());
            txtAutor.setText(libro.getAutorLi());
            int can = libro.getCantidadLi();
            txtCantidad.setText(libro.getCantidadLi()+"");
            txtUrl.setText(libro.getUrlLi());
            txtImagen.setText(libro.getImagenLi());
            txtDescripcion.setText(libro.getDescripcionLi());
        }

            btnActualizar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(!txtNombre.getText().toString().equals("")&&!txtUrl.getText().toString().equals("")&&!txtCantidad.getText().toString().equals("")&&!txtDescripcion.getText().toString().equals("")&&!txtUrl.getText().toString().equals("")){

                        lib.setId(libro.getId());
                        lib.setNombreLi(txtNombre.getText().toString());
                        lib.setAutorLi(txtAutor.getText().toString());
                        lib.setUrlLi(txtUrl.getText().toString());
                        lib.setCantidadLi(Integer.parseInt(txtCantidad.getText().toString()));
                        lib.setImagenLi(txtImagen.getText().toString());
                        lib.setDescripcionLi(txtDescripcion.getText().toString());

                        correcto = libreria.editarLibro(lib);

                        if(correcto) {
                            Toast.makeText(ActualizarLibroActivity.this, "REGISTRO MODIFICADO", Toast.LENGTH_LONG).show();
                            volver();
                        }else
                        {
                            Toast.makeText(ActualizarLibroActivity.this, "ERROR AL MODIFICADAR", Toast.LENGTH_LONG).show();
                        }
                    }else
                    {
                        Toast.makeText(ActualizarLibroActivity.this, "DEBE LLENAR LOS CAMPOS OBLIGATORIOS", Toast.LENGTH_LONG).show();
                    }
                }
            });

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });
    }

    private void volver()
    {
        Intent intent = new Intent(this, PagPrincipal.class);
        startActivity(intent);
    }

    private void limpiar()
    {
        txtNombre.setText("");
        txtAutor.setText("");
        txtCantidad.setText("");
        txtUrl.setText("");
        txtImagen.setText("");
        txtDescripcion.setText("");
    }
}