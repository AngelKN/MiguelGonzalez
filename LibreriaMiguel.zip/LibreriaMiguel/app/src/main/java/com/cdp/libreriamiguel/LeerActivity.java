package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.atributos.Libro;

public class LeerActivity extends AppCompatActivity {

    SharedPreference sp;
    TextView txtRol, txtNombreA, txtTitulo;
    int id = 0;
    ImageButton btnReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leer);

        btnReturn=findViewById(R.id.btnMenuAdmin);
        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        txtTitulo=findViewById(R.id.txtTituloAdmin);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));

        if(savedInstanceState == null){
            Bundle extras = getIntent().getExtras();
            if(extras == null){
                id = Integer.parseInt(null);
            }else{
                id = extras.getInt("ID");
            }
        }else
        {
            id = (int) savedInstanceState.getSerializable("ID");
        }

        DBLibreria libreria = new DBLibreria(LeerActivity.this);

        Libro libro = libreria.verLibroPrestados(id);
        txtTitulo.setText(libro.getNombreLi());

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });

    }

    private void volver()
    {
        Intent intent = new Intent(this, MiPrestarLibroActivity.class);
        startActivity(intent);
    }
}