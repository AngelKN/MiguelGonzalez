package com.cdp.libreriamiguel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.cdp.libreriamiguel.DB.DBLibreria;
import com.cdp.libreriamiguel.atributos.Libro;

public class AgregarActivity extends AppCompatActivity {

    EditText txtNombre, txtAutor, txtCantidad, txtUrl, txtImagen, txtDescripcion, error;
    ImageButton btnReturn;
    Button btnActualizar;
    Libro lib;
    int id=0;
    boolean correcto;
    SharedPreference sp;
    TextView txtRol, txtNombreA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
        btnReturn=findViewById(R.id.btnMenuAdmin);
        btnActualizar=findViewById(R.id.btnActualizarLibro);
        txtNombre=findViewById(R.id.txtNombreLibro);
        txtAutor=findViewById(R.id.txtAutorLibro);
        txtCantidad=findViewById(R.id.txtCantidadLibros);
        txtUrl=findViewById(R.id.txtUrlLibro);
        txtImagen=findViewById(R.id.txtImagenLibro);
        txtDescripcion=findViewById(R.id.txtDescripcionLibro);
        error=findViewById(R.id.txtError);
        error.setInputType(InputType.TYPE_NULL);
        correcto = false;
        lib = new Libro();

        txtRol=findViewById(R.id.txtRolActualizar);
        txtNombreA=findViewById(R.id.txtNombreActualizar);
        sp = new SharedPreference(this);
        txtRol.setText(sp.getSharedPreferences("rol"));
        txtNombreA.setText(sp.getSharedPreferences("nombre"));

        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long id = 0;
                DBLibreria libreria = new DBLibreria(AgregarActivity.this);

                lib.setNombreLi(txtNombre.getText().toString());
                lib.setAutorLi(txtAutor.getText().toString());
                lib.setUrlLi(txtUrl.getText().toString());
                lib.setCantidadLi(Integer.parseInt(txtCantidad.getText().toString()));
                lib.setImagenLi(txtImagen.getText().toString());
                lib.setDescripcionLi(txtDescripcion.getText().toString());


                if(!txtNombre.getText().toString().equals("")&&!txtUrl.getText().toString().equals("")&&!txtCantidad.getText().toString().equals("")&&!txtDescripcion.getText().toString().equals("")&&!txtUrl.getText().toString().equals("")){

                    id = libreria.insertarLibro(lib);

                    if(id > 0){
                        Toast.makeText(AgregarActivity.this, "LIBRO GUARDADO", Toast.LENGTH_LONG).show();
                        error.setVisibility(View.INVISIBLE);
                        limpiar();
                        volver();
                    }else
                    {
                        Toast.makeText(AgregarActivity.this, "LIBRO NO GUARDADO", Toast.LENGTH_LONG).show();
                        error.setVisibility(View.VISIBLE);
                        error.setText("LIBRO NO GUARDADO");
                    }
                }else{
                    Toast.makeText(AgregarActivity.this, "DEBE INGRESAR LOS ESPACIOS", Toast.LENGTH_LONG).show();
                    error.setVisibility(View.VISIBLE);
                    error.setText("DEBE INGRESAR LOS ESPACIOS");
                    //https://assets.puzzlefactory.pl/puzzle/448/451/original.jpg
                }
            }
        });

        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                volver();
            }
        });
    }

    private void volver(){
        Intent intent = new Intent(this, PagPrincipal.class);
        startActivity(intent);
    }

    private void limpiar()
    {
        txtNombre.setText("");
        txtAutor.setText("");
        txtCantidad.setText("");
        txtUrl.setText("");
        txtImagen.setText("");
        txtDescripcion.setText("");
    }
}