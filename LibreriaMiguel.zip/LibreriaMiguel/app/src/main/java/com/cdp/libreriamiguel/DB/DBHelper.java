package com.cdp.libreriamiguel.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NOMBRE = "Libreria.db";
    public static final String TABLE_REGISTROS = "T_Registros";
    public static final String TABLE_LIBROS = "T_Libros";
    public static final String TABLE_PRESTADOS = "T_Presatos";

    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NOMBRE, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_REGISTROS+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "nombre TEXT not null,"+
                "correo TEXT NOT NULL,"+
                "telefono TEXT NOT NULL," +
                "direccion TEXT NOT NULL," +
                "contraseña TEXT NOT NULL," +
                "rol TEXT NOT NULL)");

        ContentValues values = new ContentValues();
        values.put("nombre", "Pepito Perez");
        values.put("correo", "q@q");
        values.put("telefono", "123456789");
        values.put("direccion", "carre 17 calla2");
        values.put("contraseña", "123");
        values.put("rol", "Administrador");
        sqLiteDatabase.insert(TABLE_REGISTROS, null, values);

        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_LIBROS+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "nombreLi TEXT not null,"+
                "autorLi TEXT ,"+
                "cantidadLi INTEGER ," +
                "urlLi TEXT NOT NULL," +
                "imagenLi TEXT ," +
                "descripcionLi TEXT)");

        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_PRESTADOS+"("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "correoUs TEXT not null,"+
                "fechahora TEXT not null,"+
                //nose
                "nombreLi TEXT not null,"+
                "autorLi TEXT ,"+
                "cantidadLi INTEGER NOT NUll ," +
                "urlLi TEXT NOT NULL," +
                "imagenLi TEXT ," +
                "descripcionLi TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL(" DROP TABLE " + TABLE_LIBROS);
        sqLiteDatabase.execSQL(" DROP TABLE " + TABLE_REGISTROS);
        sqLiteDatabase.execSQL(" DROP TABLE " + TABLE_PRESTADOS);
    }
}
