package com.cdp.libreriamiguel.adaptadores;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.cdp.libreriamiguel.MiPrestarLibroActivity;
import com.cdp.libreriamiguel.R;
import com.cdp.libreriamiguel.atributos.Libro;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ListaUsuariosAdapter extends RecyclerView.Adapter<ListaUsuariosAdapter.LibroViewHolder> {

    ArrayList<Libro> listaLibro;

    public ListaUsuariosAdapter(ArrayList<Libro> listaLibro){
        this.listaLibro = listaLibro;
    }

    @NonNull
    @Override
    public ListaUsuariosAdapter.LibroViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_lista_item_suarios, null, false);
        return new ListaUsuariosAdapter.LibroViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListaUsuariosAdapter.LibroViewHolder holder, int position) {
        holder.viewNombre.setText(listaLibro.get(position).getNombreLi());
        holder.viewTelefono.setText(listaLibro.get(position).getAutorLi());
        holder.viewCorreo.setText(listaLibro.get(position).getCorreo());
    }

    @Override
    public int getItemCount() {
        return listaLibro.size();
    }

    public class LibroViewHolder extends RecyclerView.ViewHolder {

        TextView viewNombre, viewTelefono, viewCorreo;

        public LibroViewHolder(@NonNull View itemView) {
            super(itemView);
            viewNombre=itemView.findViewById(R.id.viewNombreLibro);
            viewTelefono=itemView.findViewById(R.id.viewAutorLibro);
            viewCorreo=itemView.findViewById(R.id.viewDescrip);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();

                }
            });
        }
    }
}